var mainApp = angular.module("mainApp",['ngRoute']);

mainApp.config(['$routeProvider',function($routeProvider) {
	$routeProvider.
					when('/articles', {
						templateUrl: 'components/Articles/articles.htm',
						controller: 'ArticlesController'
				}).
					when('/transactions', {
						templateUrl: 'components/Transactions/transactions.htm',
						controller: 'TransactionsController'
				}).
					when('/acteurs', {
						templateUrl: 'components/Acteurs/acteurs.htm',
						controller: 'ViewActeursController'
				}).
					when('/maintenance', {
						templateUrl: 'components/Maintenance/maintenance.htm',
						controller: 'ViewMaintenanceController'
				}).
					when('/configuration', {
						templateUrl: 'components/Configuration/configuration.htm',
						controller: 'ViewConfigController'
				}).
					when('/analyses', {
						templateUrl: 'components/Analyses/analyses.htm',
						controller: 'ViewAnalysesController'
				}).
					when('/rapports', {
					templateUrl: 'components/Rapports/rapports.htm',
					controller: 'ViewRapportsController'
				}).
					when('/article_articles', {
					templateUrl: 'components/Articles/articles/article_articles.htm',
					controller: 'ArticlesController'
				}).
					when('/viewStudents', {
					templateUrl: 'viewStudents.htm',
					controller: 'ViewStudentsController'
				}).
					otherwise({
					redirectTo: '/'
				});
}]);


