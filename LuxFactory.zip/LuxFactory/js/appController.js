mainApp.controller('appController',['$scope', function($scope) {
	
	$scope.getUserName =  function(){
		return  "Alexis Tadifo";
	};

	
	$scope.displayArticlesIcon = true;
	$scope.displayArticles = true;
	$scope.displayZoneStockage = false;

	$scope.displayMenuIcon = function(item){
		if(item === 'articles') 
		{
			$scope.displayArticlesIcon = true;
			$scope.displayTransactionsIcon = false;
			$scope.displayActeursIcon = false;
			$scope.displayMaintenanceIcon = false;
			$scope.displayConfigurationIcon = false;
			$scope.displayAnalysesIcon = false;
			$scope.displayRapportsIcon = false;
		}
		if(item === 'transactions') 
		{
			$scope.displayArticlesIcon = false;
			$scope.displayTransactionsIcon = true;
			$scope.displayActeursIcon = false;
			$scope.displayMaintenanceIcon = false;
			$scope.displayConfigurationIcon = false;
			$scope.displayAnalysesIcon = false;
			$scope.displayRapportsIcon = false;
		}	
		if(item === 'acteurs') 
		{
			$scope.displayArticlesIcon = false;
			$scope.displayTransactionsIcon = false;
			$scope.displayActeursIcon = true;
			$scope.displayMaintenanceIcon = false;
			$scope.displayConfigurationIcon = false;
			$scope.displayAnalysesIcon = false;
			$scope.displayRapportsIcon = false;
		}	
		if(item === 'maintenance') 
		{
			$scope.displayArticlesIcon = false;
			$scope.displayTransactionsIcon = false;
			$scope.displayActeursIcon = false;
			$scope.displayMaintenanceIcon = true;
			$scope.displayConfigurationIcon = false;
			$scope.displayAnalysesIcon = false;
			$scope.displayRapportsIcon = false;
		}
		if(item === 'configuration') 
		{
			$scope.displayArticlesIcon = false;
			$scope.displayTransactionsIcon = false;
			$scope.displayActeursIcon = false;
			$scope.displayMaintenanceIcon = false;
			$scope.displayConfigurationIcon = true;
			$scope.displayActeursIcon = false;
			$scope.displayRapportsIcon = false;
		}	
		if(item === 'analyses') 
		{
			$scope.displayArticlesIcon = false;
			$scope.displayTransactionsIcon = false;
			$scope.displayActeursIcon = false;
			$scope.displayMaintenanceIcon = false;
			$scope.displayConfigurationIcon = false;
			$scope.displayAnalysesIcon = true;
			$scope.displayRapportsIcon = false;
		}	
		if(item === 'rapports') 
		{
			$scope.displayArticlesIcon = false;
			$scope.displayTransactionsIcon = false;
			$scope.displayActeursIcon = false;
			$scope.displayMaintenanceIcon = false;
			$scope.displayConfigurationIcon = false;
			$scope.displayAnalysesIcon = false;
			$scope.displayRapportsIcon = true;
		}	
	}


}]);

