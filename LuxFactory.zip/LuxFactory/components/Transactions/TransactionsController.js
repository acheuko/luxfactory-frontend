mainApp.controller('TransactionsController', function($scope) {
			$scope.message = "This page will be used to display transactions items";
		});