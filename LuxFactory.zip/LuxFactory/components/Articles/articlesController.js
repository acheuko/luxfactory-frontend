mainApp.controller('ArticlesController',['$scope','$http', function($scope,$http) {
	
	$scope.displayArticles = true;
	$scope.displayZoneStockage = false;


	$scope.display = function(item){
		if(item === 'articles') 
		{
			$scope.displayArticles = true;
			$scope.displayZoneStockage = false;
			$scope.displayActivites = false;
			$scope.displayCategories = false;
		}
		if(item === 'zoneStockage') 
		{
			$scope.displayArticles = false;
			$scope.displayZoneStockage = true;
			$scope.displayActivites = false;
			$scope.displayCategories = false;
		}	
		if(item === 'activites') 
		{
			$scope.displayArticles = false;
			$scope.displayZoneStockage = false;
			$scope.displayActivites = true;
			$scope.displayCategories = false;
		}	
		if(item === 'categories') 
		{
			$scope.displayArticles = false;
			$scope.displayZoneStockage = false;
			$scope.displayActivites = false;
			$scope.displayCategories = true;
		}	
	};

	var url="components/Articles/articles.json";
	$http.get(url).then(function(success) {
		$scope.articles = success.data;
	});


}]);

