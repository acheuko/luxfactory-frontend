mainApp.controller('viewarticleController',['$scope','$http', function($scope,$http) {
	
	var url="components/Articles/articles.json";
	$http.get(url).then(function(success) {
		$scope.articles = success.data;
	});


}]);